
 The Pirx Commander for CP/M-86 Operating System
 ----------------------------------------------------------
 
 The Pirx Commander for CP/M-86 is a two-panel file browser.
 In terms of layout, it is similar to the Norton Commander for MsDos
 (see the screenshots).
 
 For your convenience this release consists of 2 parts:
 1. A set of all files in a separate subdirectory (here: "Files")
 2. Ready to use 320 KB CP/M-86 floppy disk image (here: "PirxDisk.img").
 
 Installing:
 
 If you run CP/M-86 under any IBM PC emulator then just copy the disk image 
 PirxDisk.img into this emulator. Pirx's files are stored in disk's user area 0.
 
 If you run CP/M-86 under real hardware then copy either files or disk image
 to a floppy disk. 
 
 Running:
 To start the Pirx Commander just type at the CP/M-86 system prompt:
        pirx [ENTER]
        
 If you have any questions then first read the tutorial PirxMan.txt.
  
 Marek Starobrat
 
 
 
 The copyright Notice
 ====================
    Copyright (C) 2022  Marek Starobrat

    This program is a free software.
    This is pre-release, test version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    
    See the included LICENSE.TXT
